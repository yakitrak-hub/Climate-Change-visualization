# INFO-3300-Project-1

Our final visualization(s) are in **index.html**. 

The data we import is all stored in the *data/* folder. Images used are in the *images/* folder. Everything in the *old_stuff/* folder is not used in our final product.